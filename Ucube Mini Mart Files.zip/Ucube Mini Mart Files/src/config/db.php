<?php
class db{
    //Db Properties
    private $sa_dbhost ='localhost';
    private $sa_dbuser ='root';
    private $sa_dbpass ='';
    private $sa_dbName ='ja_stock';

    //Mysql connect fucntion
    public function connect(){
        $mysql_connect_str= "mysql:host=$this->sa_dbhost;dbname=$this->sa_dbName;";
        $dbConnection= new PDO($mysql_connect_str, $this->sa_dbuser,$this->sa_dbpass);
        $dbConnection->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
        return $dbConnection;
    }
}
?>
