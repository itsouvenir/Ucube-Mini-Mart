<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app = new \Slim\App;

//Get all products
$app->get('/api/products', function (Request $request, Response $response) {
$sql='SELECT * FROM ja_products';
try {
  $db = new db();
  $db = $db->connect();
  $stmt = $db->query($sql);
  $products=$stmt->fetchAll(PDO::FETCH_OBJ);
  $db=null;
  echo json_encode($products);
} catch (PDOException $e) {
echo '{"Error":{"text":'. $e->getMessage().' }';
}
});

//Get single Product
$app->get('/api/product/{id}', function (Request $request, Response $response) {
$id=$request->getAttribute('id');
$sql="SELECT * FROM ja_products WHERE pid=$id";
try {
  $db = new db();
  $db = $db->connect();
  $stmt = $db->query($sql);
  $product=$stmt->fetchAll(PDO::FETCH_OBJ);
  //$product=$products['PName'];
  $db=null;
  echo json_encode($product);
} catch (PDOException $e) {
echo '{"Error":{"text":'. $e->getMessage().' }';
}
});


//insert products
$app->post('/api/product/add', function (Request $request, Response $response) {
// get parameters

$pname=$request->getparam('pname');
$qty=$request->getparam('qty');
$sid=$request->getparam('sid');
$umeasure=$request->getparam('umeasure');
$uprice=$request->getparam('uprice');

$sql="INSERT INTO ja_products (pname,qty,sid,umeasure,uprice) VALUES(:pname,:qty,:sid,:umeasure,:uprice)";
try {
  $db = new db();
  $db = $db->connect();
  $stmt = $db->prepare($sql);
  //$products=$stmt->fetchAll(PDO::FETCH_OBJ);

  $stmt->bindParam(':pname', $pname);
  $stmt->bindParam(':qty', $qty);
  $stmt->bindParam(':sid', $sid);
  $stmt->bindParam(':umeasure', $umeasure);
  $stmt->bindParam(':uprice', $uprice);

  $stmt->execute();
  echo '{"notice":{"text":"Product Added"}';
} catch (PDOException $e) {
echo '{"Error":{"text":'. $e->getMessage().' }';
}
});

//Update Products
$app->put('/api/product/update/{id}', function (Request $request, Response $response) {
// get parameters
$id= $request->getAttribute('id');
$pname=$request->getparam('pname');
$qty=$request->getparam('qty');
$sid=$request->getparam('sid');
$umeasure=$request->getparam('umeasure');
$uprice=$request->getparam('uprice');

$sql="UPDATE ja_products set pname=:pname,qty=:qty,sid=:sid,umeasure=:umeasure,uprice=:uprice WHERE pid=$id";
try {
  $db = new db();
  $db = $db->connect();
  $stmt = $db->prepare($sql);
  //$products=$stmt->fetchAll(PDO::FETCH_OBJ);

  $stmt->bindParam(':pname', $pname);
  $stmt->bindParam(':qty', $qty);
  $stmt->bindParam(':sid', $sid);
  $stmt->bindParam(':umeasure', $umeasure);
  $stmt->bindParam(':uprice', $uprice);

  $stmt->execute();
  echo '{"notice":{"text":"Product Updated"}';
} catch (PDOException $e) {
echo '{"Error":{"text":'. $e->getMessage().' }';
}
});

//delete products
$app->delete('/api/product/delete/{id}', function (Request $request, Response $response) {
// get parameters
$id= $request->getAttribute('id');

$sql="DELETE FROM ja_products WHERE pid=$id";
try {
  $db = new db();
  $db = $db->connect();
  $stmt = $db->prepare($sql);
  //$products=$stmt->fetchAll(PDO::FETCH_OBJ);
  $stmt->execute();
  echo '{"notice":{"text":"Product Deleted"}';
} catch (PDOException $e) {
echo '{"Error":{"text":'. $e->getMessage().' }';
}
});

//Sales made for payment
//insert products
$app->post('/api/payment/add', function (Request $request, Response $response) {
// get parameters

$amount=$request->getparam('amount');
$pid=$request->getparam('pid');
$qty=$request->getparam('qty');

$sql="INSERT INTO ja_payment (amount,pid,qty) VALUES(:amount,:pid,:qty)";
try {
  $db = new db();
  $db = $db->connect();
  $stmt = $db->prepare($sql);
  //$products=$stmt->fetchAll(PDO::FETCH_OBJ);

  $stmt->bindParam(':amount', $amount);
  $stmt->bindParam(':pid', $pid);
  $stmt->bindParam(':qty', $qty);


  $stmt->execute();
  echo '{"notice":{"text":"Payment processed successfully"}';
} catch (PDOException $e) {
echo '{"Error":{"text":'. $e->getMessage().' }';
}
});

//Make an order
$app->post('/api/order/add', function (Request $request, Response $response) {
// get parameters

$amount=$request->getparam('item');
$pid=$request->getparam('qty');
$qty=$request->getparam('loc');

$sql="INSERT INTO ja_orders (Item,Quantity,Location) VALUES(:Item,:Quantity,:Location)";
try {
  $db = new db();
  $db = $db->connect();
  $stmt = $db->prepare($sql);
  //$products=$stmt->fetchAll(PDO::FETCH_OBJ);

  $stmt->bindParam(':Item', $amount);
  $stmt->bindParam(':Quantity', $pid);
  $stmt->bindParam(':Location', $qty);


  $stmt->execute();
  echo '{"notice":{"text":"Order processed successfully"}';
} catch (PDOException $e) {
echo '{"Error":{"text":'. $e->getMessage().' }';
}
});

?>
