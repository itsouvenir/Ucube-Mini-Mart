-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 06, 2018 at 07:00 AM
-- Server version: 5.7.21
-- PHP Version: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ja_stock`
--
CREATE DATABASE IF NOT EXISTS `ja_stock` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `ja_stock`;

-- --------------------------------------------------------

--
-- Table structure for table `ja_orders`
--

DROP TABLE IF EXISTS `ja_orders`;
CREATE TABLE IF NOT EXISTS `ja_orders` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `Item` varchar(50) NOT NULL,
  `Quantity` int(15) NOT NULL,
  `Location` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ja_orders`
--

INSERT INTO `ja_orders` (`id`, `Item`, `Quantity`, `Location`) VALUES
(1, 'Sugar', 2, 'Entebbe');

-- --------------------------------------------------------

--
-- Table structure for table `ja_payment`
--

DROP TABLE IF EXISTS `ja_payment`;
CREATE TABLE IF NOT EXISTS `ja_payment` (
  `payid` int(4) NOT NULL AUTO_INCREMENT,
  `amount` int(15) NOT NULL,
  `pid` int(5) NOT NULL,
  `qty` int(15) NOT NULL,
  PRIMARY KEY (`payid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ja_payment`
--

INSERT INTO `ja_payment` (`payid`, `amount`, `pid`, `qty`) VALUES
(1, 2000, 2, 10),
(2, 3000, 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `ja_products`
--

DROP TABLE IF EXISTS `ja_products`;
CREATE TABLE IF NOT EXISTS `ja_products` (
  `pid` int(4) NOT NULL AUTO_INCREMENT,
  `pname` varchar(25) NOT NULL,
  `qty` int(25) NOT NULL,
  `sid` int(8) NOT NULL,
  `umeasure` varchar(10) NOT NULL,
  `uprice` int(50) NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ja_products`
--

INSERT INTO `ja_products` (`pid`, `pname`, `qty`, `sid`, `umeasure`, `uprice`) VALUES
(1, 'Kiwi', 20, 2, 'Tins', 50000),
(2, 'Skin Care Jelly', 60, 2, 'Boxes', 49000),
(5, 'Colgate', 30, 2, 'pack', 4000),
(6, 'White star', 70, 2, 'bars', 50000),
(7, 'Detol Herbal', 100, 1, 'pcs', 20000),
(12, 'Blue Band Magrine', 42, 2, 'Tins', 20000),
(13, 'Colgate Herbal', 42, 3, 'Boxes', 20000),
(14, 'Jik', 20, 3, 'Box', 21000);

-- --------------------------------------------------------

--
-- Table structure for table `ja_supplier`
--

DROP TABLE IF EXISTS `ja_supplier`;
CREATE TABLE IF NOT EXISTS `ja_supplier` (
  `SID` int(8) NOT NULL AUTO_INCREMENT,
  `SName` varchar(25) NOT NULL,
  `Contact` int(13) NOT NULL,
  `Address` varchar(50) NOT NULL,
  PRIMARY KEY (`SID`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ja_supplier`
--

INSERT INTO `ja_supplier` (`SID`, `SName`, `Contact`, `Address`) VALUES
(1, 'Movit', 777536473, 'Zana kampala (U)'),
(2, 'Samona', 754983847, 'Nateete Complex '),
(3, 'Mulwana', 256705674, 'Kiboga Busunju');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
CREATE TABLE IF NOT EXISTS `login` (
  `id` int(44) NOT NULL AUTO_INCREMENT,
  `username` varchar(16) NOT NULL,
  `password` varchar(255) NOT NULL,
  `uname` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `password`, `uname`) VALUES
(1, 'admin', '202cb962ac59075b964b07152d234b70', 'Alexandrea');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
