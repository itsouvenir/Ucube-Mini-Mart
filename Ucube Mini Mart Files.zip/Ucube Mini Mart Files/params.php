put
http://stock.io/api/product/update/1?pname=Kiwi&qty=20&sid=2&umeasure=Tins&uprice=50000
