<?PHP
require_once("./include/membersite_config.php");

if(!$fgmembersite->CheckLogin())
{
    $fgmembersite->RedirectToURL("login.php");
    exit;
}

?>
<!DOCTYPE html>
<html>
    <?php include("inc/tables-header.php"); ?>
    <body>

        <!-- Loader -->
        <div id="preloader"><div id="status"><div class="spinner"></div></div></div>

        <!-- Navigation Bar-->
        <header id="topnav">
            <div class="topbar-main">
                <div class="container-fluid">

                    <!-- Logo container-->
                    <div class="logo">
                        <!-- Text Logo -->
                        <!--<a href="index.html" class="logo">-->
                        <!--Upcube-->
                        <!--</a>-->
                        <!-- Image Logo -->
                        <a href="login-home.php" class="logo">
                            <img src="assets\images\logo-sm.png" alt="" height="22" class="logo-small">
                            <img src="assets\images\logo.png" alt="" height="24" class="logo-large">
                        </a>

                    </div>
                    <!-- End Logo container-->


                    <div class="menu-extras topbar-custom">

                        <!-- Search input -->


                        <ul class="list-inline float-right mb-0">
                            <!-- Search -->

                            <!-- Messages-->

                            <!-- notification-->

                            <!-- User-->
                            <li class="list-inline-item dropdown notification-list">
                                <a class="nav-link dropdown-toggle arrow-none waves-effect nav-user" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                                    <img src="assets\images\users\avatar-1.jpg" alt="user" class="rounded-circle">
                                </a>
                                <div class="dropdown-menu dropdown-menu-right profile-dropdown ">
                                    <a class="dropdown-item" href="logout.php"><i class="dripicons-exit text-muted"></i> Logout</a>
                                </div>
                            </li>
                            <li class="menu-item list-inline-item">
                                <!-- Mobile menu toggle-->
                                <a class="navbar-toggle nav-link">
                                    <div class="lines">
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                    </div>
                                </a>
                                <!-- End mobile menu toggle-->
                            </li>

                        </ul>
                    </div>
                    <!-- end menu-extras -->

                    <div class="clearfix"></div>

                </div> <!-- end container -->
            </div>
            <!-- end topbar-main -->
              <?php include("include/menu.php"); ?>
        <div class="wrapper">
            <div class="container-fluid">

                <!-- Page-Title -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-title-box">
                            <h4 class="page-title">Dashboard</h4>
                        </div>
                    </div>

                </div>
                <!-- end page title end breadcrumb -->

                <div class="row">
                    <div class="col-12">
                        <div class="card m-b-30">
                            <div class="card-body">
                                <h4 class="mt-0 m-b-15 header-title">Recent Products</h4>

                                      <?php include("sqlFunctions/product.php")?>
                                    </div>
                        </div>
                    </div>

                </div>
                <!-- end row -->

            </div> <!-- end container -->
        </div>
        <!-- end wrapper -->
        <?php include("include/footer.php"); ?>
        <!-- jQuery  -->
        <script src="assets\js\jquery.min.js"></script>
        <script src="assets\js\popper.min.js"></script>
        <script src="assets\js\bootstrap.min.js"></script>
        <script src="assets\js\modernizr.min.js"></script>
        <script src="assets\js\waves.js"></script>
        <script src="assets\js\jquery.slimscroll.js"></script>
        <script src="assets\js\jquery.nicescroll.js"></script>
        <script src="assets\js\jquery.scrollTo.min.js"></script>

        <!-- Required datatable js -->
        <script src="assets\plugins\datatables\jquery.dataTables.min.js"></script>
        <script src="assets\plugins\datatables\dataTables.bootstrap4.min.js"></script>
        <!-- Buttons examples -->
        <script src="assets\plugins\datatables\dataTables.buttons.min.js"></script>
        <script src="assets\plugins\datatables\buttons.bootstrap4.min.js"></script>
        <script src="assets\plugins\datatables\jszip.min.js"></script>
        <script src="assets\plugins\datatables\pdfmake.min.js"></script>
        <script src="assets\plugins\datatables\vfs_fonts.js"></script>
        <script src="assets\plugins\datatables\buttons.html5.min.js"></script>
        <script src="assets\plugins\datatables\buttons.print.min.js"></script>
        <script src="assets\plugins\datatables\buttons.colVis.min.js"></script>
        <!-- Responsive examples -->
        <script src="assets\plugins\datatables\dataTables.responsive.min.js"></script>
        <script src="assets\plugins\datatables\responsive.bootstrap4.min.js"></script>

        <!-- Datatable init js -->
        <script src="assets\pages\datatables.init.js"></script>

        <!-- App js -->
        <script src="assets\js\app.js"></script>

    </body>
</html>
