<?php

$pname=$_POST['pname'];
$qty=$_POST['qty'];
$sid=$_POST['sid'];
$umeasure=$_POST['umeasure'];
$uprice=$_POST['uprice'];
include('../../../src/config/db.php');
$sql="INSERT INTO ja_products (pname,qty,sid,umeasure,uprice) VALUES('$pname','$qty','$sid','$umeasure','$uprice')";
try {
  $db = new db();
  $db = $db->connect();
  $stmt = $db->prepare($sql);
  //$products=$stmt->fetchAll(PDO::FETCH_OBJ);

  $stmt->execute();
  echo '{"notice":{"text":"Product Added"}';
  header("location:../login-add-product.php");
} catch (PDOException $e) {
echo '{"Error":{"text":'. $e->getMessage().' }';
}
?>
