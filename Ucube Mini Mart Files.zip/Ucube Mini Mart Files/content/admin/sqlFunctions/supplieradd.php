<?php
include('../../../src/config/db.php');
$sname=$_POST['sname'];
$contact=$_POST['contact'];
$address=$_POST['address'];

$sql="INSERT INTO ja_supplier (SID,SName,Contact,Address) VALUES(null,'$sname','$contact','$address')";
try {
  $db = new db();
  $db = $db->connect();
  $stmt = $db->prepare($sql);
  //$products=$stmt->fetchAll(PDO::FETCH_OBJ);

  $stmt->execute();
  echo '{"notice":{"text":"Supplier Added"}';
  header("location:../login-add-supplier.php"); //to redirect back to "index.php" after logging out

} catch (PDOException $e) {
echo '{"Error":{"text":'. $e->getMessage().' }';
}
?>
