<!--    <table class="table table-hover mb-0">
        <thead>
        <tr>
            <th>Product Name</th>
            <th>Quantity</th>
            <th>Unit of Measure</th>
            <th>Price</th>
        </tr>

        </thead>
        <tbody>
        <tr>
            <td>Tiger Nixon</td>
            <td>System Architect</td>
            <td><span class="badge badge-info">Active</span></td>
            <td>61</td>
        </tr>
        </tbody>
    </table>
-->
<?php
include('../../src/config/db.php');
echo '<table id="datatable-buttons" class="table table-striped table-bordered" cellspacing="0" width="100%">
          <thead>
        <tr>
            <th>Order ID.</th>
            <th>Item</th>
            <th>Quantity</th>
            <th>Location</th>
        </tr>

        </thead>';
include('../../src/config/table.php');
$sql="SELECT * FROM ja_orders";
try {
  $db = new db();
  $db = $db->connect();
  $stmt = $db->prepare($sql);
  //$product=$stmt->fetchAll(PDO::FETCH_ASSOC);
  $stmt->execute();
      echo "<tbody>";
      // set the resulting array to associative
      $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
      foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
          echo $v;
      }
        echo "<tbody>";
} catch (PDOException $e) {
echo 'Error:text:'. $e->getMessage();
}
?>
