<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <title>Upcube -stock platform</title>
    <meta content="Admin Dashboard" name="description">
    <meta content="Themesdesign" name="author">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!--other-->
    <meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>

    <!--Morris Chart CSS -->
    <link rel="stylesheet" href="assets\plugins\morris\morris.css">


    <script type='text/javascript' src='scripts/gen_validatorv31.js'></script>
    <!-- App Icons -->
    <link rel="shortcut icon" href="assets\images\favicon.ico">

    <!-- App css -->
    <link href="assets\css\bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="assets\css\icons.css" rel="stylesheet" type="text/css">
    <link href="assets\css\style.css" rel="stylesheet" type="text/css">

</head>
