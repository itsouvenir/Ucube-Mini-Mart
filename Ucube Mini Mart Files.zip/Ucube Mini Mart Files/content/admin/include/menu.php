<!-- MENU Start -->
<div class="navbar-custom">
    <div class="container-fluid">
        <div id="navigation">
            <!-- Navigation Menu-->
            <ul class="navigation-menu">

                <li class="has-submenu">
                    <a href="login-home.php"><i class="ti-home"></i>Dashboard</a>
                </li>

                <li class="has-submenu">
                    <a href="login-add-product.php"><i class="ti-light-bulb"></i>Add Products</a>

                </li>

                <li class="has-submenu">
                    <a href="login-view-products.php"><i class="ti-crown"></i>View Products</a>

                </li>

                <li class="has-submenu">
                    <a href="login-add-supplier.php"><i class="ti-bookmark-alt"></i>Add Supplier</a>
                </li>

                <li class="has-submenu">
                    <a href="login-view-supplier.php"><i class="ti-files"></i>View Supplier</a>

                </li>
                <li class="has-submenu">
                    <a href="login-view-payment.php"><i class="typcn typcn-zoom-outline"></i>View Payment</a>

                </li>
                <li class="has-submenu">
                    <a href="login-view-orders.php"><i class="typcn typcn-zoom-outline"></i>View Orders</a>

                </li>

            </ul>
            <!-- End navigation menu -->
        </div> <!-- end #navigation -->
    </div> <!-- end container -->
</div> <!-- end navbar-custom -->
</header>
<!-- End Navigation Bar-->
