<!-- Footer -->
<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                © 2018 Upcube 
            </div>
        </div>
    </div>
</footer>
<!-- End Footer -->
