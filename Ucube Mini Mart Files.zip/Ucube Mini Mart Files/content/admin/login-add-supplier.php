<?PHP
require_once("./include/membersite_config.php");

if(!$fgmembersite->CheckLogin())
{
    $fgmembersite->RedirectToURL("login.php");
    exit;
}

?>
<!DOCTYPE html>
<html>
    <?php include("inc/header.php"); ?>
    <body>

        <!-- Loader -->
        <div id="preloader"><div id="status"><div class="spinner"></div></div></div>

        <!-- Navigation Bar-->
        <header id="topnav">
            <div class="topbar-main">
                <div class="container-fluid">

                    <!-- Logo container-->
                    <div class="logo">
                        <!-- Text Logo -->
                        <!--<a href="index.html" class="logo">-->
                        <!--Upcube-->
                        <!--</a>-->
                        <!-- Image Logo -->
                        <a href="login-home.php" class="logo">
                            <img src="assets\images\logo-sm.png" alt="" height="22" class="logo-small">
                            <img src="assets\images\logo.png" alt="" height="24" class="logo-large">
                        </a>

                    </div>
                    <!-- End Logo container-->


                    <div class="menu-extras topbar-custom">

                        <!-- Search input -->


                        <ul class="list-inline float-right mb-0">
                            <!-- Search -->

                            <!-- Messages-->

                            <!-- notification-->

                            <!-- User-->
                            <li class="list-inline-item dropdown notification-list">
                                <a class="nav-link dropdown-toggle arrow-none waves-effect nav-user" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                                    <img src="assets\images\users\avatar-1.jpg" alt="user" class="rounded-circle">
                                </a>
                                <div class="dropdown-menu dropdown-menu-right profile-dropdown ">
                                    <a class="dropdown-item" href="logout.php"><i class="dripicons-exit text-muted"></i> Logout</a>
                                </div>
                            </li>
                            <li class="menu-item list-inline-item">
                                <!-- Mobile menu toggle-->
                                <a class="navbar-toggle nav-link">
                                    <div class="lines">
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                    </div>
                                </a>
                                <!-- End mobile menu toggle-->
                            </li>

                        </ul>
                    </div>
                    <!-- end menu-extras -->

                    <div class="clearfix"></div>

                </div> <!-- end container -->
            </div>
            <!-- end topbar-main -->
              <?php include("include/menu.php"); ?>
        <div class="wrapper">
            <div class="container-fluid">

                <!-- Page-Title -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-title-box">
                            <h4 class="page-title">Supplier</h4>
                        </div>
                    </div>
                </div>
                <!-- end page title end breadcrumb -->

                <div class="row">

                    <div class="col-xl-8">
                        <div class="card m-b-30">
                            <div class="card-body">
                                <h4 class="mt-0 m-b-15 header-title">Add Supplier Form</h4>
                                <form method="post" action="sqlFunctions/supplieradd.php">
                                  <div class="form-group row">
                                      <label for="example-text-input-sm" class="col-sm-2 col-form-label">Supplier Name</label>
                                      <div class="col-sm-10">
                                          <input name="sname" class="form-control form-control-sm" type="text" placeholder="Type here ...e.g Mukwano" id="example-text-input-sm">
                                      </div>
                                  </div>
                                  <div class="form-group row">
                                      <label for="example-tel-input" class="col-sm-2 col-form-label">Telephone</label>
                                      <div class="col-sm-10">
                                          <input name="contact" class="form-control" type="tel" value="+2565555555" id="example-tel-input">
                                      </div>
                                  </div>
                                  <div class="form-group row">
                                      <label for="example-text-input-sm" class="col-sm-2 col-form-label">Address</label>
                                      <div class="col-sm-10">
                                          <input name="address" class="form-control form-control-sm" type="text" placeholder="Type here an address....e.g Kampala Ug" id="example-text-input-sm">
                                      </div>
                                  </div>
                                  <div class="button-items">
                                      <input type="submit" class="btn btn-success btn-lg btn-block" value="Save">
                                  </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4">
                        <div class="card m-b-30">
                            <div class="card-body">
                                <h4 class="mt-0 header-title">Monthly Earnings</h4>

                                <ul class="list-inline widget-chart m-t-20 text-center">
                                    <li>
                                        <h4 class=""><b>3654</b></h4>
                                        <p class="text-muted m-b-0">Marketplace</p>
                                    </li>
                                    <li>
                                        <h4 class=""><b>954</b></h4>
                                        <p class="text-muted m-b-0">Last week</p>
                                    </li>
                                    <li>
                                        <h4 class=""><b>8462</b></h4>
                                        <p class="text-muted m-b-0">Last Month</p>
                                    </li>
                                </ul>

                                <div id="morris-donut-example" style="height: 265px"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end row -->

            </div> <!-- end container -->
        </div>
        <!-- end wrapper -->
        <?php include("include/footer.php"); ?>
        <!-- jQuery  -->
        <script src="assets\js\jquery.min.js"></script>
        <script src="assets\js\popper.min.js"></script>
        <script src="assets\js\bootstrap.min.js"></script>
        <script src="assets\js\modernizr.min.js"></script>
        <script src="assets\js\waves.js"></script>
        <script src="assets\js\jquery.slimscroll.js"></script>
        <script src="assets\js\jquery.nicescroll.js"></script>
        <script src="assets\js\jquery.scrollTo.min.js"></script>

        <!--Morris Chart-->
        <script src="assets\plugins\morris\morris.min.js"></script>
        <script src="assets\plugins\raphael\raphael-min.js"></script>

        <script src="assets\pages\dashborad.js"></script>

        <!-- App js -->
        <script src="assets\js\app.js"></script>

    </body>
</html>
