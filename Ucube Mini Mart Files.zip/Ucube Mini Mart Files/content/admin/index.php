<?PHP
// Report simple running errors
error_reporting(E_ERROR | E_WARNING | E_PARSE);
require_once("./include/membersite_config.php");

if(isset($_POST['submitted']))
{
   if($fgmembersite->Login())
   {
        $fgmembersite->RedirectToURL("login-home.php");
   }
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<?php include("inc/header.php"); ?>
<body>

  <!-- Form Code Start -->
  <div id='fg_membersite'>
    <!-- Begin page -->
    <div class="accountbg"></div>
    <div class="wrapper-page">

        <div class="card">
            <div class="card-body">

                <h3 class="text-center mt-0 m-b-15">
                    <a href="index-1.html" class="logo logo-admin"><img src="assets\images\logo-dark.png" height="30" alt="logo"></a>
                </h3>

                <h4 class="text-muted text-center font-18"><b>Sign In</b></h4>

                <div class="p-3">
                    <form id='login' class="form-horizontal m-t-20" action="<?php echo $fgmembersite->GetSelfScript(); ?>" method='post' accept-charset='UTF-8'>
                        <input type='hidden' name='submitted' id='submitted' value='1'/>
                        <div class="form-group row">
                            <div class="col-12">
                              <input class="form-control" type='text' required="" placeholder="Username" name='username' id='username' value='<?php echo $fgmembersite->SafeDisplay('username') ?>' maxlength="50" /><br/>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-12">
                                <input class="form-control" type="password" required="" placeholder="Password"name='password' id='password'>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-12">
                                <div class="custom-control custom-checkbox">
                                    <input type="checkbox" class="custom-control-input" id="customCheck1">
                                    <label class="custom-control-label" for="customCheck1">Remember me</label>
                                </div>
                            </div>
                        </div>

                        <div class="form-group text-center row m-t-20">
                            <div class="col-12">
                                <button class="btn btn-info btn-block waves-effect waves-light" type="submit">Log In</button>
                            </div>
                        </div>

                        <div class="form-group m-t-10 mb-0 row">
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>



    <!-- jQuery  -->
    <script src="assets\js\jquery.min.js"></script>
    <script src="assets\js\popper.min.js"></script>
    <script src="assets\js\bootstrap.min.js"></script>
    <script src="assets\js\modernizr.min.js"></script>
    <script src="assets\js\waves.js"></script>
    <script src="assets\js\jquery.slimscroll.js"></script>
    <script src="assets\js\jquery.nicescroll.js"></script>
    <script src="assets\js\jquery.scrollTo.min.js"></script>

    <!-- App js -->
    <script src="assets\js\app.js"></script>
  <!-- client-side Form Validations:
  Uses the excellent form validation script from JavaScript-coder.com-->

  <script type='text/javascript'>
  // <![CDATA[

      var frmvalidator  = new Validator("login");
      frmvalidator.EnableOnPageErrorDisplay();
      frmvalidator.EnableMsgsTogether();

      frmvalidator.addValidation("username","req","Please provide your username");

      frmvalidator.addValidation("password","req","Please provide the password");

  // ]]>
  </script>
  </div>
  <!--
  Form Code End (see html-form-guide.com for more info.)
  -->

</body>
</html>
